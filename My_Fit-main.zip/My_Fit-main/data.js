// This file is now deprecated and can be deleted.
// All data is loaded from app_data.json via the Fetch API in script.js.
